package com.masterhaxixu;

import org.bukkit.event.Listener;
import com.masterhaxixu.Commands.FFARegen;
import com.onarandombox.MultiverseCore.MultiverseCore;
import com.onarandombox.MultiverseCore.api.MVWorldManager;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

//import me.realized.duels.api.Duels;

public class Main extends JavaPlugin implements Listener {
    FileConfiguration config = getConfig();
    Map<UUID, Location> playerloc = new HashMap<UUID, Location>();

    @Override
    public void onEnable() {
        //config.options().copyDefaults(true);
        saveConfig(); 
        getServer().getPluginManager().registerEvents(this, this);
        this.getCommand("regenffa").setExecutor(new FFARegen(config));
        
        int duration = Integer.parseInt(config.getString("duration"));
        new BukkitRunnable() {
            @Override
            public void run() {

                if(config.getBoolean("enabled")) {
                    Bukkit.broadcastMessage(ChatColor.RED+"["+ChatColor.GOLD+"Server Announcement"+ChatColor.RED+"] Regenerating Flat Arena.");
                    String world1 = config.getString("modelworld");
                    String world2 = config.getString("resetworld");
                    //int newycord = Integer.parseInt(config.getString("y-level-of-tp"));
                    String world3 = config.getString("world-between-regen");
                    int xcord = Integer.parseInt(config.getString("x"));
                    int ycord = Integer.parseInt(config.getString("y"));
                    int zcord = Integer.parseInt(config.getString("z"));
                    
                    MultiverseCore core = (MultiverseCore) Bukkit.getServer().getPluginManager()
                    .getPlugin("Multiverse-Core");
            MVWorldManager worldManager = core.getMVWorldManager();
            World world = Bukkit.getServer().getWorld(world3);
                for (Player p : Bukkit.getServer().getWorld(world2).getPlayers()) {
                    playerloc.put(p.getUniqueId(), p.getLocation());
                    p.teleport(new Location(world, xcord, ycord, zcord));
                }
                worldManager.deleteWorld(world2);
                worldManager.cloneWorld(world1, world2);
                worldManager.loadWorld(world2);
                worldManager.getMVWorld(world2).setAlias(world2);
                World newffa = Bukkit.getServer().getWorld(world2);
                for(Map.Entry<UUID, Location> entry : playerloc.entrySet()) {
                    UUID playeruuid = entry.getKey();
                    Location playercords = entry.getValue();
                    Player p = Bukkit.getPlayer(playeruuid);
                    p.teleport(new Location(newffa, playercords.getX(), playercords.getY(), playercords.getZ(), playercords.getYaw(), playercords.getPitch()));
                }
                Bukkit.broadcastMessage(ChatColor.RED+"["+ChatColor.GOLD+"Server Announcement"+ChatColor.RED+"] Regenerated Flat Arena.");
                playerloc.clear();
            }
            }
        }.runTaskTimer(this, 0L, 20 * 60 * duration);
        
        
    }

    @Override
    public void onDisable() {
    }
}