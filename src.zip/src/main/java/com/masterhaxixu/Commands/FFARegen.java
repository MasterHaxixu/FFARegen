package com.masterhaxixu.Commands;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import com.onarandombox.MultiverseCore.MultiverseCore;
import com.onarandombox.MultiverseCore.api.MVWorldManager;

public class FFARegen implements CommandExecutor {
    String world1;
    String world2;
    String world3;
    int xcord;
    int ycord;
    int zcord;

    public FFARegen(FileConfiguration config) {
        world1 = config.getString("modelworld");
        world2 = config.getString("resetworld");
        world3 = config.getString("world-between-regen");
        xcord = Integer.parseInt(config.getString("x"));
        ycord = Integer.parseInt(config.getString("y"));
        zcord = Integer.parseInt(config.getString("z"));
    }

    Map<UUID, Location> playerloc = new HashMap<UUID, Location>();

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Bukkit.broadcastMessage(ChatColor.RED+"["+ChatColor.GOLD+"Server Announcement"+ChatColor.RED+"] Regenerating Flat Arena.");
        MultiverseCore core = (MultiverseCore) Bukkit.getServer().getPluginManager()
                .getPlugin("Multiverse-Core");
        MVWorldManager worldManager = core.getMVWorldManager();
        World world = Bukkit.getServer().getWorld(world3);
        for (Player p : Bukkit.getServer().getWorld(world2).getPlayers()) {
            playerloc.put(p.getUniqueId(), p.getLocation());
            p.teleport(new Location(world, xcord, ycord, zcord));
        }
        worldManager.deleteWorld(world2);
        worldManager.cloneWorld(world1, world2);
        worldManager.loadWorld(world2);
        worldManager.getMVWorld(world2).setAlias(world2);
        World newffa = Bukkit.getServer().getWorld(world2);
        for (Map.Entry<UUID, Location> entry : playerloc.entrySet()) {
            UUID playeruuid = entry.getKey();
            Location playercords = entry.getValue();
            Player p = Bukkit.getPlayer(playeruuid);
            p.teleport(new Location(newffa, playercords.getX(), playercords.getY(), playercords.getZ(), playercords.getYaw(), playercords.getPitch()));
        }
        Bukkit.broadcastMessage(ChatColor.RED+"["+ChatColor.GOLD+"Server Announcement"+ChatColor.RED+"] Regenerated Flat Arena.");
        playerloc.clear();
        return true;

    }

}